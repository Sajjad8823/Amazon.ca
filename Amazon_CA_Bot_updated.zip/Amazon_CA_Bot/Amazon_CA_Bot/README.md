# Amazon.ca Scraper Bot

Same shape as your previous Amazon bot, retargeted at `amazon.ca`, saving
straight to an **Excel file** instead of a SQLite database.

## What it does

For each keyword you list in `run.py`:

1. Opens `https://www.amazon.ca/s?k=<keyword>`.
2. Scrolls down the results page gradually (not one big jump) so every
   lazy-loaded product/image on the page actually loads.
3. Collects every product link (via `data-asin`) on that page.
4. Clicks "Next" and repeats, up to `max_pages`.
5. Visits each collected product page and scrapes:
   - **Title** - full product listing title
   - **Product Link** - clickable URL to the product page
   - **Seller** - name of the seller shown on the product page
   - **Manufacturer** - manufacturer/brand from the technical details table
   - **Main Image Link** - direct URL of the main product image
6. Appends each row straight into `output/amazon_ca_products.xlsx` (same
   columns as your sample sheet, plus the new "Main Image Link" column),
   saving the file after every product so nothing is lost if you stop
   the bot early. Re-running skips URLs that are already in the sheet.

## Setup

```bash
pip install -r requirements.txt
```

You also need a matching Chrome + chromedriver on your machine (same as
your previous bot's setup).

## Running it

Edit the configuration block at the top of `main()` in `run.py`:

```python
search_terms = ["nebulizer", "vitamin c serum"]  # any keywords you want
max_pages = 3                                    # pages per keyword
HEADLESS = False                                 # keep visible at first
EXCEL_FILE = "output/amazon_ca_products.xlsx"
```

Then run:

```bash
python run.py
```

## About the selectors

The seller and manufacturer selectors were built directly from the
inspect-element screenshots you shared:

- **Seller**: Amazon renders a "Sold by" label in one div and the actual
  seller name in a sibling div
  (`div.offer-display-feature-text[data-csa-c-content-id="desktop-merchant-info"]`).
  The bot reads that sibling's text. If that div isn't present (some
  listings are sold directly "by Amazon.ca" and skip it), it falls back
  to `#sellerProfileTriggerId`, then `#merchant-info`, then defaults to
  `"Amazon"`.
- **Manufacturer**: pulled from the "Technical Details" table
  (`#productDetails_techSpec_section_1`), matching the row whose label is
  "Manufacturer". Falls back to the detail-bullets list, then to the
  "Brand: X" byline near the title if neither table exists.

Amazon changes its page markup fairly often and slightly differently
across product categories, so if you notice missing Seller/Manufacturer
values on a run, send me a fresh inspect-element screenshot of that
product page and I'll add another fallback selector.

## Handling CAPTCHAs / robot checks

Unlike Amazon.nl, browsing amazon.ca search/product pages usually doesn't
require being logged in. If Amazon does show its "type the characters you
see" robot check, the bot detects it, pauses, and asks you to solve it in
the visible Chrome window - then press Enter in the terminal to continue.
Keep `HEADLESS = False` while you're getting this dialed in so you can see
and solve these if they appear.

## A note on Amazon's Terms of Service

Amazon's Conditions of Use restrict automated scraping of its site. This
bot is provided as a technical tool the way your previous one was; use of
it against amazon.ca is your responsibility - keep request rates
human-like (the bot already adds randomized delays), and don't use it in
a way that violates Amazon's terms or applicable law.

## File layout

```
Amazon_CA_Bot/
├── run.py                  # entry point - edit keywords/settings here
├── requirements.txt
├── config/settings.yaml    # reference config (not auto-loaded by run.py)
├── src/
│   ├── browser.py          # Chrome/selenium-wire wrapper, gradual scroll, CAPTCHA pause
│   ├── excel_writer.py     # replaces the old database.py - writes rows to .xlsx
│   └── scraper.py          # search pagination + product page extraction
├── output/                 # amazon_ca_products.xlsx gets created here
└── screenshots/            # optional debug screenshots
```
