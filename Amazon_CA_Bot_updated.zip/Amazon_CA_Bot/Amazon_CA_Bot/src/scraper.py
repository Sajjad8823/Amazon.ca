import time
import random
import logging
import re
import traceback
from urllib.parse import quote_plus
from selenium.webdriver.common.by import By

from browser import SimpleBrowser
from excel_writer import ExcelWriter

logger = logging.getLogger(__name__)


class AmazonCaScraper:
    """
    Amazon.ca search + product scraper.

    For every keyword in `search_terms`:
      1. Open the search results page.
      2. Scroll down gradually (so lazy-loaded images/products trigger)
         and collect every product link on the page.
      3. Move to the next results page and repeat, up to `max_pages`.
      4. Visit each collected product page and scrape:
           - Full product title
           - Clickable product URL
           - Seller name
           - Manufacturer / brand
           - Main image URL
      5. Write each product straight into the Excel output file.
    """

    BASE_URL = "https://www.amazon.ca"

    def __init__(self, search_terms, max_pages=3, headless=False,
                 proxy=None, skip_duplicates=True, excel_file="output/amazon_ca_products.xlsx"):
        self.search_terms = search_terms if isinstance(search_terms, list) else [search_terms]
        self.max_pages = max_pages
        self.headless = headless
        self.proxy = proxy
        self.skip_duplicates = skip_duplicates

        self.browser = None
        self.writer = ExcelWriter(excel_file=excel_file)
        self.items_scraped = 0

    # ------------------------------------------------------------------
    # Top level control flow
    # ------------------------------------------------------------------
    def start(self):
        logger.info("=" * 60)
        logger.info("AMAZON.CA SCRAPER STARTING")
        logger.info("=" * 60)

        try:
            self.browser = SimpleBrowser(headless=self.headless, proxy=self.proxy)
            self.browser.start()

            for term in self.search_terms:
                logger.info(f"\n{'='*60}")
                logger.info(f"SEARCHING FOR: {term}")
                logger.info(f"{'='*60}")
                self._search_and_scrape(term)

            logger.info(f"\n{'='*60}")
            logger.info(f"SCRAPING COMPLETED. Total items saved: {self.items_scraped}")
            logger.info(f"{'='*60}")

        except Exception as e:
            logger.error(f"Scraper error: {e}")
            logger.error(traceback.format_exc())
            raise
        finally:
            if self.browser:
                self.browser.close()

    # ------------------------------------------------------------------
    # Search results pages
    # ------------------------------------------------------------------
    def _search_and_scrape(self, term):
        search_url = f"{self.BASE_URL}/s?k={quote_plus(term)}"
        logger.info(f"Opening search URL: {search_url}")

        if not self.browser.open_page(search_url):
            logger.error("Failed to open search page")
            return

        if self.browser.is_captcha_page():
            self.browser.wait_for_manual_captcha_solve()

        all_links = []
        page_num = 1

        while page_num <= self.max_pages:
            logger.info(f"\n--- Search results page {page_num}/{self.max_pages} for '{term}' ---")

            # Scroll gradually down the page so every lazy-loaded product/image
            # on this results page has a chance to load before we scrape it.
            self.browser.scroll_page_gradually()

            page_links = self._get_product_links()
            new_links = [l for l in page_links if l not in all_links]
            logger.info(f"Found {len(page_links)} products on this page ({len(new_links)} new)")
            all_links.extend(new_links)

            if page_num >= self.max_pages:
                break

            if not self._go_to_next_page():
                logger.info("No further pages available.")
                break

            page_num += 1
            time.sleep(random.uniform(2, 4))

            if self.browser.is_captcha_page():
                self.browser.wait_for_manual_captcha_solve()

        logger.info(f"Total unique products collected for '{term}': {len(all_links)}")

        for idx, link in enumerate(all_links, 1):
            logger.info(f"\n{'='*60}")
            logger.info(f"PRODUCT {idx}/{len(all_links)} for '{term}'")
            logger.info(f"URL: {link}")

            if self.skip_duplicates and self.writer.product_exists(link):
                logger.info("Already in Excel file - skipping.")
                continue

            self._scrape_product_page(link, term)

            delay = random.uniform(3, 6)
            logger.info(f"Waiting {delay:.1f}s before next product...")
            time.sleep(delay)

    def _get_product_links(self):
        """Collect product URLs (via data-asin) from the currently loaded search page."""
        links = []
        try:
            selectors = [
                '[data-component-type="s-search-result"]',
                'div[data-asin]',
                '.s-result-item',
            ]

            containers = []
            for selector in selectors:
                containers = self.browser.driver.find_elements(By.CSS_SELECTOR, selector)
                if containers:
                    logger.debug(f"Found {len(containers)} containers with selector: {selector}")
                    break

            for container in containers:
                try:
                    asin = container.get_attribute('data-asin')
                    if asin:
                        clean_url = f"{self.BASE_URL}/dp/{asin}"
                        if clean_url not in links:
                            links.append(clean_url)
                        continue

                    link_elem = container.find_element(By.CSS_SELECTOR, 'h2 a, .a-link-normal')
                    href = link_elem.get_attribute('href')
                    asin = self._extract_asin(href) if href else None
                    if asin:
                        clean_url = f"{self.BASE_URL}/dp/{asin}"
                        if clean_url not in links:
                            links.append(clean_url)
                except Exception:
                    continue

        except Exception as e:
            logger.error(f"Error getting product links: {e}")

        return links

    def _go_to_next_page(self):
        """Click Amazon's 'Next' pagination link if it's present and enabled."""
        try:
            next_candidates = self.browser.driver.find_elements(
                By.CSS_SELECTOR, 'a.s-pagination-next, .s-pagination-item.s-pagination-next'
            )
            for next_btn in next_candidates:
                classes = next_btn.get_attribute('class') or ''
                if 'disabled' in classes or 's-pagination-disabled' in classes:
                    return False
                self.browser.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", next_btn)
                time.sleep(0.5)
                self.browser.driver.execute_script("arguments[0].click();", next_btn)
                time.sleep(3)
                return True
            return False
        except Exception as e:
            logger.debug(f"Could not go to next page: {e}")
            return False

    @staticmethod
    def _extract_asin(url):
        patterns = [
            r'/dp/([A-Z0-9]{10})',
            r'/gp/product/([A-Z0-9]{10})',
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        return None

    # ------------------------------------------------------------------
    # Individual product page
    # ------------------------------------------------------------------
    def _scrape_product_page(self, url, search_term):
        try:
            if not self.browser.open_page(url):
                logger.error("Failed to open product page")
                return

            if self.browser.is_captcha_page():
                self.browser.wait_for_manual_captcha_solve()
                self.browser.open_page(url)

            time.sleep(3)

            title = self._extract_title()
            seller = self._extract_seller()
            manufacturer = self._extract_manufacturer()
            image_url = self._extract_main_image()

            logger.info(f"✓ Title: {title[:70] if title else ''}")
            logger.info(f"✓ Seller: {seller}")
            logger.info(f"✓ Manufacturer: {manufacturer}")
            logger.info(f"✓ Image: {image_url[:70] if image_url else ''}")

            row = {
                "date_run": time.strftime("%d.%m.%Y"),
                "product": search_term,
                "title": title,
                "url": url,
                "seller": seller,
                "manufacturer": manufacturer,
                "image_url": image_url,
            }

            if self.writer.save_product(row):
                self.items_scraped += 1
                logger.info(f"✅ SAVED PRODUCT {self.items_scraped} to Excel")
            else:
                logger.error("❌ Failed to save product row to Excel")

        except Exception as e:
            logger.error(f"Error scraping product {url}: {e}")
            logger.error(traceback.format_exc())

    def _extract_title(self):
        selectors = [
            '#titleSection #title',
            '#productTitle',
            '#title',
            'h1.a-size-large',
        ]
        for selector in selectors:
            try:
                elem = self.browser.driver.find_element(By.CSS_SELECTOR, selector)
                title = elem.text.strip()
                if title:
                    return title
            except Exception:
                continue
        return ""

    def _extract_main_image(self):
        selectors = [
            '#landingImage',
            '#imgBlkFront',
            '#main-image',
            '.a-dynamic-image',
        ]
        for selector in selectors:
            try:
                elem = self.browser.driver.find_element(By.CSS_SELECTOR, selector)
                img_url = elem.get_attribute('src')
                if img_url and 'http' in img_url:
                    return img_url
            except Exception:
                continue
        return ""

    def _extract_seller(self):
        """
        Based on the product page structure: a 'Sold by' label div sits next
        to a sibling div (data-csa-c-content-id="desktop-merchant-info",
        class "offer-display-feature-text") that holds the actual seller name.
        """
        try:
            elem = self.browser.driver.find_element(
                By.CSS_SELECTOR,
                'div.offer-display-feature-text[data-csa-c-content-id="desktop-merchant-info"]'
            )
            text = elem.text.strip()
            if text:
                return text
        except Exception:
            pass

        try:
            elem = self.browser.driver.find_element(By.ID, "sellerProfileTriggerId")
            text = elem.text.strip()
            if text:
                return text
        except Exception:
            pass

        try:
            elem = self.browser.driver.find_element(By.ID, "merchant-info")
            text = elem.text.strip()
            match = re.search(r'Sold by[:\s]*([^.|]+)', text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
            if text:
                return text
        except Exception:
            pass

        return "Amazon"

    def _extract_manufacturer(self):
        """
        Based on the 'Product information' -> 'Technical Details' table
        (table#productDetails_techSpec_section_1), where the first row's
        left cell says 'Manufacturer' and the right cell has the value.
        """
        table_selectors = [
            '#productDetails_techSpec_section_1',
            '#productDetails_detailBullets_sections1',
        ]
        for selector in table_selectors:
            try:
                table = self.browser.driver.find_element(By.CSS_SELECTOR, selector)
                rows = table.find_elements(By.CSS_SELECTOR, 'tr')
                for row in rows:
                    try:
                        label_elem = row.find_element(By.CSS_SELECTOR, 'th, td:first-child')
                        label = label_elem.text.strip().lower()
                        if 'manufacturer' in label:
                            value_elem = row.find_element(By.CSS_SELECTOR, 'td:last-child')
                            value = value_elem.text.strip()
                            if value:
                                return value
                    except Exception:
                        continue
            except Exception:
                continue

        # Fallback: detail bullets list (some listings use <ul><li> instead of a table)
        try:
            bullets = self.browser.driver.find_elements(
                By.CSS_SELECTOR, '#detailBullets_feature_div li'
            )
            for bullet in bullets:
                text = bullet.text.strip()
                if 'manufacturer' in text.lower():
                    parts = text.split(':', 1)
                    if len(parts) == 2:
                        return parts[1].strip()
        except Exception:
            pass

        # Last resort: the "Brand: X" byline near the title
        try:
            elem = self.browser.driver.find_element(By.ID, "bylineInfo")
            text = elem.text.strip()
            match = re.search(r'Brand[:\s]*([^.|]+)', text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        except Exception:
            pass

        return ""
