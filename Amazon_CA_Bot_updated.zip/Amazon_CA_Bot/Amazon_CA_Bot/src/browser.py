import os
import time
import random
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

# selenium-wire is used instead of plain selenium so authenticated
# residential proxies (host:port with user:pass) work out of the box.
from seleniumwire import webdriver as wire_webdriver
from selenium.webdriver.chrome.options import Options

logger = logging.getLogger(__name__)


class SimpleBrowser:
    """Thin wrapper around a Chrome driver with retry + human-like helpers."""

    def __init__(self, headless=False, proxy=None):
        self.headless = headless
        self.proxy = proxy
        self.driver = None

    def start(self):
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                logger.info(f"Starting Chrome... Attempt {attempt + 1}/{max_attempts}")

                chrome_options = Options()

                if self.headless:
                    chrome_options.add_argument('--headless=new')

                chrome_options.add_argument('--window-size=1920,1080')
                chrome_options.add_argument("--disable-blink-features=AutomationControlled")
                chrome_options.add_argument("--no-first-run")
                chrome_options.add_argument("--no-default-browser-check")
                chrome_options.add_argument("--disable-dev-shm-usage")
                chrome_options.add_argument("--disable-gpu")
                chrome_options.add_argument("--disable-software-rasterizer")
                chrome_options.add_argument("--no-sandbox")
                chrome_options.add_argument("--disable-setuid-sandbox")
                chrome_options.add_argument("--remote-allow-origins=*")

                seleniumwire_options = None
                if self.proxy:
                    import re
                    pattern = r'http://([^:]+):([^@]+)@([^:]+):(\d+)'
                    match = re.match(pattern, self.proxy)

                    if match:
                        username, password, host, port = match.groups()
                        logger.info(f"Using authenticated proxy: {host}:{port}")
                        seleniumwire_options = {
                            'proxy': {
                                'http': f'http://{username}:{password}@{host}:{port}',
                                'https': f'http://{username}:{password}@{host}:{port}',
                            }
                        }
                    else:
                        logger.info(f"Using proxy: {self.proxy}")
                        seleniumwire_options = {
                            'proxy': {'http': self.proxy, 'https': self.proxy}
                        }

                self.driver = wire_webdriver.Chrome(
                    options=chrome_options,
                    seleniumwire_options=seleniumwire_options
                )

                time.sleep(3)

                handles = self.driver.window_handles
                if len(handles) == 0:
                    raise WebDriverException("Browser has no windows")

                logger.info("Chrome started successfully!")
                return self.driver

            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed: {e}")
                if self.driver:
                    try:
                        self.driver.quit()
                    except Exception:
                        pass
                    self.driver = None

                if attempt < max_attempts - 1:
                    logger.info("Waiting 5 seconds before retry...")
                    time.sleep(5)
                else:
                    logger.error("All attempts to start Chrome failed")
                    raise

    def open_page(self, url):
        try:
            try:
                _ = self.driver.current_url
            except Exception:
                logger.error("Browser window closed unexpectedly!")
                return False

            logger.info(f"Opening: {url}")
            self.driver.get(url)
            time.sleep(3)

            page_source = self.driver.page_source
            if any(err in page_source for err in [
                "ERR_PROXY_CONNECTION_FAILED", "This site can't be reached"
            ]):
                logger.error(f"Proxy connection failed for {url}")
                return False

            title = self.driver.title
            if title:
                logger.info(f"Page loaded: {title[:60]}")
                return True
            return False

        except Exception as e:
            logger.error(f"Error opening page: {e}")
            return False

    def is_captcha_page(self):
        """Detect Amazon's 'Enter the characters you see' robot check page."""
        try:
            page_source = self.driver.page_source.lower()
            return (
                'captchacharacters' in page_source
                or "type the characters you see" in page_source
                or "enter the characters you see" in page_source
            )
        except Exception:
            return False

    def wait_for_manual_captcha_solve(self):
        """Pause and let a human solve the CAPTCHA / robot check in the open window."""
        print("\n" + "=" * 60)
        print("AMAZON ROBOT CHECK / CAPTCHA DETECTED")
        print("Please solve it in the Chrome window that opened.")
        print("=" * 60)
        input("Press ENTER here once the page has loaded normally again...")
        time.sleep(2)

    def find_elements(self, css_selector, timeout=10):
        try:
            _ = self.driver.current_url
            wait = WebDriverWait(self.driver, timeout)
            elements = wait.until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, css_selector))
            )
            return elements
        except (TimeoutException, WebDriverException):
            return []
        except Exception:
            return []

    def scroll_page_gradually(self, pause_min=0.6, pause_max=1.4, steps=None):
        """
        Scroll down the page in small human-like increments so that all
        lazy-loaded images/products on the page get triggered, instead of
        jumping straight to the bottom.
        """
        try:
            last_height = self.driver.execute_script("return document.body.scrollHeight")
            current_position = 0
            step = 0
            max_steps = steps or 40

            while step < max_steps:
                scroll_amount = random.randint(350, 650)
                current_position += scroll_amount
                self.driver.execute_script(f"window.scrollTo(0, {current_position});")
                time.sleep(random.uniform(pause_min, pause_max))

                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if current_position >= new_height:
                    # Reached (or passed) the bottom of the page
                    if new_height == last_height:
                        break
                    last_height = new_height
                step += 1

            # Small settle scroll back up a touch, then to the very bottom once more
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1)

        except Exception as e:
            logger.debug(f"Gradual scroll failed: {e}")

    def scroll_down(self):
        try:
            scroll_amount = random.randint(300, 700)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            time.sleep(random.uniform(1, 2))
        except Exception as e:
            logger.debug(f"Scroll failed: {e}")

    def save_screenshot(self, filename):
        try:
            if not os.path.exists('screenshots'):
                os.makedirs('screenshots')
            filepath = f"screenshots/{filename}"
            self.driver.save_screenshot(filepath)
            logger.info(f"Screenshot saved: {filepath}")
        except Exception as e:
            logger.error(f"Could not save screenshot: {e}")

    def close(self):
        if self.driver:
            try:
                self.driver.quit()
                logger.info("Browser closed")
            except Exception:
                pass
