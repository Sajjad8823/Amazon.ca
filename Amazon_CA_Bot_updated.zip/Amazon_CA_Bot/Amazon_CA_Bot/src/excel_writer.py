import os
import logging
import openpyxl
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

HEADERS = [
    "Date Run",
    "Product",          # search keyword used
    "Title",            # full product title
    "URL",              # clickable product link
    "Seller",           # seller name shown on the product page
    "Manufacturer",     # manufacturer / brand
    "Main Image Link",  # direct URL of the main product image
]


class ExcelWriter:
    

    def __init__(self, excel_file="output/amazon_ca_products.xlsx"):
        self.excel_file = excel_file
        os.makedirs(os.path.dirname(self.excel_file) or ".", exist_ok=True)
        self._existing_urls = set()
        self._init_workbook()

    def _init_workbook(self):
        if os.path.exists(self.excel_file):
            logger.info(f"Loading existing Excel file: {self.excel_file}")
            self.wb = openpyxl.load_workbook(self.excel_file)
            self.ws = self.wb.active
            # Build a set of already-scraped URLs so re-running doesn't duplicate rows
            url_col_idx = None
            for idx, cell in enumerate(self.ws[1], start=1):
                if cell.value == "URL":
                    url_col_idx = idx
                    break
            if url_col_idx:
                for row in self.ws.iter_rows(min_row=2, values_only=False):
                    url_cell = row[url_col_idx - 1]
                    if url_cell.value:
                        self._existing_urls.add(str(url_cell.value).strip())
        else:
            logger.info(f"Creating new Excel file: {self.excel_file}")
            self.wb = openpyxl.Workbook()
            self.ws = self.wb.active
            self.ws.title = "Sheet1"
            self.ws.append(HEADERS)
            for col_idx, header in enumerate(HEADERS, start=1):
                self.ws.column_dimensions[get_column_letter(col_idx)].width = max(15, len(header) + 4)
            self.wb.save(self.excel_file)

    def product_exists(self, url):
        return url in self._existing_urls

    def save_product(self, row: dict):
        
        try:
            self.ws.append([
                row.get("date_run", ""),
                row.get("product", ""),
                row.get("title", ""),
                row.get("url", ""),
                row.get("seller", ""),
                row.get("manufacturer", ""),
                row.get("image_url", ""),
            ])
            self.wb.save(self.excel_file)
            self._existing_urls.add(row.get("url", ""))
            return True
        except Exception as e:
            logger.error(f"Failed to save row to Excel: {e}")
            return False
