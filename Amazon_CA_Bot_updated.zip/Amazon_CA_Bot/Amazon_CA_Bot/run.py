import logging
import sys
import os
import traceback

sys.stdout.reconfigure(line_buffering=True)

print("=" * 60)
print("AMAZON.CA SCRAPER - Starting...")
print(f"Python version: {sys.version}")
print(f"Working directory: {os.getcwd()}")
print("=" * 60)

try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

    print("Importing scraper modules...")
    from scraper import AmazonCaScraper
    print("✓ AmazonCaScraper imported successfully")

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    print("✓ Logging configured")

except Exception as e:
    print(f"✗ IMPORT ERROR: {e}")
    traceback.print_exc()
    input("Press Enter to exit...")
    sys.exit(1)


def main():
    print("\n" + "=" * 60)
    print("MAIN FUNCTION STARTING")
    print("=" * 60)

    

    # One or more keywords to search on amazon.ca. Each keyword is searched
    # in turn; every matching product across the pages you allow gets scraped.
    search_terms = ["ac fan"]

    # How many search-results pages to go through, per keyword.
    max_pages = 2

    # Keep this False so you can see the browser and solve a CAPTCHA/robot
    # check manually if Amazon ever shows one. Set True to run invisibly
    # once you've confirmed the bot works reliably on your machine.
    HEADLESS = False

    # Optional authenticated proxy, format: http://username:password@host:port
    # Leave as None if you don't need one.
    USE_PROXY = True
    PROXY_URL = "http://fec732b71aa7e8e9bf81:fbd350cf67ff6c9f@gw.dataimpulse.com:823"

    # Skip products whose URL is already saved in the output Excel file
    SKIP_DUPLICATES = True

    # Where results are saved (created automatically if it doesn't exist)
    EXCEL_FILE = "output/amazon_ca_products.xlsx"

    print(f"Search terms: {search_terms}")
    print(f"Max pages per keyword: {max_pages}")
    print(f"Headless: {HEADLESS}")
    print(f"Proxy enabled: {USE_PROXY}")
    if USE_PROXY:
        print(f"Proxy host: {PROXY_URL.split('@')[-1]}")
        print(f"Output Excel file: {EXCEL_FILE}")
        print("\n" + "=" * 60)

        try:
            print("\nCreating Amazon.ca scraper instance...")
            scraper = AmazonCaScraper(
                search_terms=search_terms,
                max_pages=max_pages,
                headless=HEADLESS,
                proxy=PROXY_URL if USE_PROXY else None,
                skip_duplicates=SKIP_DUPLICATES,
                excel_file=EXCEL_FILE,
            )
            print("✓ AmazonCaScraper created")

            print("\nStarting scraper...")
            scraper.start()
            print("✓ Scraper finished successfully")

        except Exception as e:
            print(f"\n✗ SCRAPER ERROR: {e}")
            traceback.print_exc()
            input("Press Enter to exit...")
            raise


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        traceback.print_exc()
        input("Press Enter to exit...")